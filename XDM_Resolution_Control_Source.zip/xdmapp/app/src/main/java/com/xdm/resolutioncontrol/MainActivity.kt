package com.xdm.resolutioncontrol

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 18)
    private val surface = Color.rgb(17, 24, 39)
    private val raised = Color.rgb(25, 34, 53)
    private val accent = Color.rgb(124, 92, 255)
    private val cyan = Color.rgb(56, 217, 255)
    private val white = Color.rgb(245, 247, 255)
    private val muted = Color.rgb(148, 163, 184)
    private val green = Color.rgb(34, 197, 94)
    private val prefs by lazy { getSharedPreferences("xdm_local", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var widthInput: EditText
    private lateinit var heightInput: EditText
    private lateinit var dpiInput: EditText
    private var currentWidth = 0
    private var currentHeight = 0
    private var currentDpi = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readDisplay()
        renderHome()
    }

    private fun readDisplay() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        currentWidth = metrics.widthPixels
        currentHeight = metrics.heightPixels
        currentDpi = metrics.densityDpi
    }

    private fun baseScreen(title: String, subtitle: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(16), dp(20), dp(14))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(20))
        }
        val brand = TextView(this).apply {
            text = "XDM  /  DISPLAY LAB"
            textSize = 12f
            letterSpacing = .12f
            setTextColor(cyan)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("V 1.0", 11f, muted, true))
        outer.addView(header)
        outer.addView(label(title, 28f, white, true))
        val sub = label(subtitle, 13f, muted, false)
        sub.setPadding(0, dp(5), 0, dp(18))
        outer.addView(sub)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(content)
        scroll.addView(outer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(2))
        }
        listOf("HOME", "CONFIG", "PROFILES", "HISTORY").forEachIndexed { index, item ->
            val b = TextView(this).apply {
                text = item
                textSize = 10f
                letterSpacing = .05f
                gravity = Gravity.CENTER
                setTextColor(if ((title == "Display overview" && index == 0) || (title == "Configure display" && index == 1) || (title == "Your profiles" && index == 2) || (title == "Change history" && index == 3)) cyan else muted)
                setPadding(dp(5), dp(10), dp(5), dp(10))
                setOnClickListener { when(index) { 0 -> renderHome(); 1 -> renderConfig(); 2 -> renderProfiles(); 3 -> renderHistory() } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        return root
    }

    private fun renderHome() {
        readDisplay()
        baseScreen("Display overview", "PRECISION CONTROL  •  ANDROID DISPLAY")
        val hero = card()
        hero.addView(label("CURRENT DISPLAY", 11f, cyan, true))
        hero.addView(label("$currentWidth × $currentHeight", 30f, white, true).apply { setPadding(0, dp(10), 0, dp(3)) })
        hero.addView(label("LIVE DEVICE METRICS", 10f, muted, true))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(20), 0, 0) }
        stats.addView(stat("WIDTH", "$currentWidth px"), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(stat("HEIGHT", "$currentHeight px"), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(stat("DENSITY", "$currentDpi dpi"), LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(stats)
        content.addView(hero)
        content.addView(sectionTitle("QUICK ACTIONS"))
        content.addView(actionButton("Configure resolution & DPI", "EDIT DISPLAY PARAMETERS", accent) { renderConfig() })
        content.addView(actionButton("Manage saved profiles", "CREATE · APPLY · DELETE", raised) { renderProfiles() })
        content.addView(actionButton("Restore Android defaults", "RESET SIZE AND DENSITY OVERRIDES", raised) {
            AlertDialog.Builder(this).setTitle("Restore display defaults?")
                .setMessage("This resets Android's custom size and density overrides. Continue only if you understand the effect.")
                .setNegativeButton("Cancel", null).setPositiveButton("Continue") { _, _ -> runOrCopy("wm size reset && wm density reset", "Reset display overrides") }.show()
        })
        val note = card()
        note.addView(label("ACCESS STATUS", 11f, cyan, true))
        note.addView(label("Direct system changes usually require root or an ADB/Shizuku-style privileged bridge. This app will not pretend a change succeeded when it cannot apply it.", 13f, muted, false).apply { setPadding(0, dp(8), 0, 0) })
        content.addView(note)
    }

    private fun renderConfig() {
        baseScreen("Configure display", "SET TARGET VALUES BEFORE APPLYING")
        val c = card()
        c.addView(label("RESOLUTION", 11f, cyan, true))
        widthInput = input("Width in pixels", currentWidth.toString())
        heightInput = input("Height in pixels", currentHeight.toString())
        dpiInput = input("Density DPI", currentDpi.toString())
        c.addView(fieldLabel("WIDTH")); c.addView(widthInput)
        c.addView(fieldLabel("HEIGHT")); c.addView(heightInput)
        c.addView(fieldLabel("DENSITY DPI")); c.addView(dpiInput)
        c.addView(label("Use values supported by your device. A poor configuration can make parts of Android difficult to use.", 12f, muted, false).apply { setPadding(0, dp(12), 0, dp(5)) })
        content.addView(c)
        content.addView(actionButton("Preview & validate", "CHECK INPUTS", raised) {
            val values = validated() ?: return@actionButton
            AlertDialog.Builder(this).setTitle("Configuration preview")
                .setMessage("Resolution: ${values.first} × ${values.second}\nDensity: ${values.third} DPI\n\nNo changes have been applied yet.")
                .setPositiveButton("OK", null).show()
        })
        content.addView(actionButton("Apply configuration", "ROOT REQUIRED FOR DIRECT APPLY", accent) {
            val values = validated() ?: return@actionButton
            AlertDialog.Builder(this).setTitle("Apply display changes?")
                .setMessage("Target: ${values.first} × ${values.second}\nDensity: ${values.third} DPI\n\nThe app will attempt a root shell. If root is unavailable, it will copy ADB commands for you instead.")
                .setNegativeButton("Cancel", null).setPositiveButton("Continue") { _, _ ->
                    val cmd = "wm size ${values.first}x${values.second} && wm density ${values.third}"
                    saveHistory("Requested ${values.first}x${values.second} @ ${values.third} dpi", "Prepared")
                    runOrCopy(cmd, "Apply display configuration")
                }.show()
        })
        content.addView(actionButton("Copy ADB commands", "USE FROM A COMPUTER WITH USB/WIRELESS DEBUGGING", raised) {
            val v = validated() ?: return@actionButton
            copyText("wm size ${v.first}x${v.second}\nwm density ${v.third}", "ADB commands copied")
        })
    }

    private fun renderProfiles() {
        baseScreen("Your profiles", "LOCAL PRESETS · STORED ON THIS DEVICE")
        val profiles = readProfiles()
        if (profiles.length() == 0) {
            val defaults = listOf(
                JSONObject().put("name", "Current display").put("width", currentWidth).put("height", currentHeight).put("dpi", currentDpi),
                JSONObject().put("name", "Custom profile").put("width", currentWidth).put("height", currentHeight).put("dpi", currentDpi)
            )
            defaults.forEach { profiles.put(it) }
            writeProfiles(profiles)
        }
        for (i in 0 until profiles.length()) {
            val p = profiles.optJSONObject(i) ?: continue
            val c = card()
            c.addView(label(p.optString("name", "Profile"), 17f, white, true))
            c.addView(label("${p.optInt("width")} × ${p.optInt("height")}  •  ${p.optInt("dpi")} DPI", 12f, muted, false).apply { setPadding(0, dp(5), 0, dp(12)) })
            c.addView(actionButton("Apply profile", "VALIDATE BEFORE APPLY", accent) {
                val w = p.optInt("width"); val h = p.optInt("height"); val d = p.optInt("dpi")
                if (w < 320 || h < 320 || d !in 80..1000) { toast("Profile values are invalid"); return@actionButton }
                AlertDialog.Builder(this).setTitle("Apply ${p.optString("name")}? ").setMessage("$w × $h at $d DPI")
                    .setNegativeButton("Cancel", null).setPositiveButton("Continue") { _, _ -> runOrCopy("wm size ${w}x${h} && wm density $d", "Apply profile") }.show()
            })
            c.addView(actionButton("Delete profile", "REMOVE LOCAL PRESET", raised) {
                AlertDialog.Builder(this).setTitle("Delete profile?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                    val arr = readProfiles(); val newArr = JSONArray(); for (j in 0 until arr.length()) if (j != i) newArr.put(arr.getJSONObject(j)); writeProfiles(newArr); renderProfiles()
                }.show()
            })
            content.addView(c)
        }
        content.addView(actionButton("Save current target as profile", "SAVE VALUES FROM CONFIGURATION", raised) {
            val w = currentWidth; val h = currentHeight; val d = currentDpi
            val nameBox = EditText(this).apply { hint = "Profile name"; setTextColor(white); setHintTextColor(muted) }
            AlertDialog.Builder(this).setTitle("New profile").setView(nameBox).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
                val name = nameBox.text.toString().trim().ifBlank { "My profile" }
                val arr = readProfiles().put(JSONObject().put("name", name).put("width", w).put("height", h).put("dpi", d))
                writeProfiles(arr); renderProfiles(); toast("Profile saved")
            }.show()
        })
        content.addView(label("Profiles store the current device values. To save a different target, use Configure first; profile editing can be expanded in a later build.", 12f, muted, false).apply { setPadding(dp(3), dp(6), dp(3), dp(10)) })
    }

    private fun renderHistory() {
        baseScreen("Change history", "RECENT LOCAL OPERATIONS")
        val arr = JSONArray(prefs.getString("history", "[]"))
        if (arr.length() == 0) {
            val c = card(); c.addView(label("No operations recorded yet.", 14f, muted, false)); content.addView(c)
        } else {
            for (i in arr.length() - 1 downTo 0) {
                val item = arr.optJSONObject(i) ?: continue
                val c = card(); c.addView(label(item.optString("action"), 15f, white, true)); c.addView(label(item.optString("status") + "  •  " + item.optString("time"), 11f, muted, false).apply { setPadding(0, dp(6), 0, 0) }); content.addView(c)
            }
        }
        content.addView(actionButton("Clear history", "DELETE LOCAL RECORDS", raised) {
            AlertDialog.Builder(this).setTitle("Clear history?").setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ -> prefs.edit().remove("history").apply(); renderHistory() }.show()
        })
    }

    private fun validated(): Triple<Int, Int, Int>? {
        val w = widthInput.text.toString().toIntOrNull(); val h = heightInput.text.toString().toIntOrNull(); val d = dpiInput.text.toString().toIntOrNull()
        if (w == null || h == null || d == null) { toast("Enter whole numbers in all fields"); return null }
        if (w !in 320..10000 || h !in 320..20000) { toast("Resolution is outside the accepted input range"); return null }
        if (d !in 80..1000) { toast("DPI must be between 80 and 1000"); return null }
        return Triple(w, h, d)
    }

    private fun runOrCopy(command: String, action: String) {
        Thread {
            var output = ""
            var success = false
            try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                val out = process.inputStream.bufferedReader().readText()
                val err = process.errorStream.bufferedReader().readText()
                val code = process.waitFor()
                output = (out + "\n" + err).trim()
                success = code == 0
            } catch (_: Exception) { success = false }
            runOnUiThread {
                if (success) {
                    readDisplay(); saveHistory(action, "Root apply succeeded"); toast("Command completed. Verify the display values."); renderHome()
                } else {
                    copyText(command, "No root shell detected. ADB command copied.")
                    saveHistory(action, "ADB command copied; not applied by app")
                    AlertDialog.Builder(this).setTitle("Privileged access unavailable")
                        .setMessage("The app could not execute this command with root access, so it has NOT applied the change. The command has been copied to the clipboard. Run it from an authorized ADB shell:\n\n$command\n\n${output.take(400)}")
                        .setPositiveButton("OK", null).show()
                }
            }
        }.start()
    }

    private fun readProfiles(): JSONArray = try { JSONArray(prefs.getString("profiles", "[]")) } catch (_: Exception) { JSONArray() }
    private fun writeProfiles(arr: JSONArray) { prefs.edit().putString("profiles", arr.toString()).apply() }
    private fun saveHistory(action: String, status: String) {
        val arr = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("action", action).put("status", status).put("time", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())))
        val trimmed = JSONArray(); for (i in maxOf(0, arr.length() - 100) until arr.length()) trimmed.put(arr.getJSONObject(i))
        prefs.edit().putString("history", trimmed.toString()).apply()
    }
    private fun copyText(text: String, message: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("XDM command", text)); toast(message)
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(17), dp(17), dp(17)); background = rounded(surface, 20); val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(14); layoutParams = p }
    private fun stat(name: String, value: String): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label(name, 10f, muted, true)); addView(label(value, 14f, white, true).apply { setPadding(0, dp(5), 0, 0) }) }
    private fun sectionTitle(s: String) { content.addView(label(s, 11f, muted, true).apply { setPadding(dp(3), dp(8), 0, dp(10)) }) }
    private fun fieldLabel(s: String) = label(s, 10f, muted, true).apply { setPadding(0, dp(12), 0, dp(5)) }
    private fun input(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText; setText(value); setTextColor(white); setHintTextColor(muted); textSize = 16f
        setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setPadding(dp(13), dp(10), dp(13), dp(10)); background = rounded(raised, 12)
    }
    private fun actionButton(title: String, subtitle: String, color: Int, action: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(color, 15); isClickable = true; isFocusable = true }
        box.addView(label(title, 14f, white, true)); box.addView(label(subtitle, 9f, if (color == accent) Color.WHITE else muted, true).apply { setPadding(0, dp(5), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); box.layoutParams = lp; box.setOnClickListener { hideKeyboard(); action() }; return box
    }
    private fun label(textValue: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply { text = textValue; textSize = size; setTextColor(color); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun hideKeyboard() { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(root.windowToken, 0) }
}
