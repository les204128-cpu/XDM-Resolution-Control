# XDM Resolution Control — Android source project

A native Kotlin Android Studio project for a premium dark gaming-style resolution/DPI utility.

## Implemented in this starter build
- Reads the current display metrics reported by Android.
- Resolution and DPI input with validation and a preview.
- Root-shell apply attempt (`su`) for devices that already have root access.
- If root is unavailable, copies the equivalent `wm` commands to the clipboard and clearly states that the app did not apply the change.
- Local profiles and a local operation history.
- Restore Android size/density overrides (`wm size reset && wm density reset`) via the same root-or-copy flow.
- Dark dashboard and navigation.

## Important limitations
- Direct apply is not available to an ordinary unrooted app by itself. For unrooted devices, commands must be run from an authorized ADB shell on a computer or through a separately implemented privileged bridge such as Shizuku. This project does not pretend that clipboard copying is equivalent to applying a setting.
- The app does not currently integrate Shizuku, automatic Wireless Debugging pairing, profile editing, or a guaranteed rollback timer.
- Test on the target device before relying on display changes. An unsupported size/density can make the interface difficult to use.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build APK(s).

Package: `com.xdm.resolutioncontrol`
Minimum Android: 8.0 (API 26)
Target SDK: 35

## ADB commands
Connect the phone to an authorized ADB shell, then run commands such as:

```sh
wm size 1080x2400
wm density 420
```

Reset Android overrides with:

```sh
wm size reset
wm density reset
```
